#ifndef durationcalc_h
#define durationcalc_h
#include <stdio.h>
#include "keyvaluefinder.h"


void durationCalc(double secondsToBeCalculated, AUDIO *soundVar);

#endif
