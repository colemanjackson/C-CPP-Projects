#ifndef keyvaluefinderaiff_h
#define keyvaluefinderaiff_h
#include "keyvaluefinder.h"
#include <stdio.h>



void keyValueFinderAIFF(FILE *cs229File,  AUDIO *soundVar);

#endif
