#ifndef PARSER_h
#define PARSER_h
#include <stdio.h>

int fileNameParser(FILE *fileToParse);

#endif
