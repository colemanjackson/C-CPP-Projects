

#ifndef ATOCS_h
#define ATOCS_h
#include <stdio.h>
#include "keyvaluefinder.h"

void atocs(FILE *outputFile, FILE *CS229File, AUDIO *SoundVar);


#endif
