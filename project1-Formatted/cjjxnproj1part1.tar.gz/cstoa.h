
#ifndef CSTOA_h
#define CSTOA_h
#include <stdio.h>
#include "keyvaluefinder.h"

void cstoa(FILE *outputFile, FILE *CS229File, AUDIO *SoundVar);


#endif
